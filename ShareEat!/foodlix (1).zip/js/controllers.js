angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('yourIngredientsCtrl', function($scope) {

})
      
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('addIngredientsCtrl', function($scope) {

})
   
.controller('userIgredientsCtrl', function($scope) {

})
   
.controller('userCtrl', function($scope) {

})
   
.controller('profileCtrl', function($scope) {

})
   
.controller('matchCtrl', function($scope) {

})
   
.controller('friendsCtrl', function($scope) {

})
   
.controller('rangeCtrl', function($scope) {

})
 